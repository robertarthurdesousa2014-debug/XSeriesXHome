package com.xseries.home;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private int verde = Color.rgb(16, 124, 16);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        tela.setPadding(24, 32, 24, 24);
        tela.setBackgroundColor(Color.rgb(17, 17, 17));

        TextView titulo = new TextView(this);
        titulo.setText("XBOX");
        titulo.setTextSize(30);
        titulo.setTextColor(Color.WHITE);
        titulo.setGravity(Gravity.CENTER_VERTICAL);
        tela.addView(titulo);

        TextView subtitulo = new TextView(this);
        subtitulo.setText("XSeries Home  •  v0.1");
        subtitulo.setTextSize(15);
        subtitulo.setTextColor(Color.LTGRAY);
        tela.addView(subtitulo);

        adicionarBloco(tela, "Continuar jogando", "Seus jogos recentes");
        adicionarBloco(tela, "Meus jogos e aplicativos", "Biblioteca");
        adicionarBloco(tela, "Configurações", "Personalizar sua experiência");

        setContentView(tela);
    }

    private void adicionarBloco(
            LinearLayout tela, String titulo, String descricao) {

        LinearLayout bloco = new LinearLayout(this);
        bloco.setOrientation(LinearLayout.VERTICAL);
        bloco.setGravity(Gravity.CENTER_VERTICAL);
        bloco.setPadding(20, 18, 20, 18);
        bloco.setBackgroundColor(Color.rgb(38, 38, 38));

        LinearLayout.LayoutParams parametros =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 120);

        parametros.setMargins(0, 22, 0, 0);
        tela.addView(bloco, parametros);

        TextView nome = new TextView(this);
        nome.setText(titulo);
        nome.setTextColor(Color.WHITE);
        nome.setTextSize(19);
        bloco.addView(nome);

        TextView detalhe = new TextView(this);
        detalhe.setText(descricao);
        detalhe.setTextColor(Color.LTGRAY);
        detalhe.setTextSize(14);
        bloco.addView(detalhe);
    }
}
